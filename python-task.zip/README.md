## [Umarov Kamoliddin](https://github.com/uzsoftic) (ISE-51U) 
### Data Since (Assigment-1)

> Github: [https://github.com/KIUT-Projects/data-since-assigment-1](https://github.com/KIUT-Projects/data-since-assigment-1)

# Task-1
![img_1.png](.github/img_1.png)
![img_2.png](.github/img_2.png)

# Task-2
![img_3.png](.github/img_3.png)
![img_4.png](.github/img_4.png)

# Task-3
![img_5.png](.github/img_5.png)
![img_6.png](.github/img_6.png)

# Task-4
![img_7.png](.github/img_7.png)
![img_8.png](.github/img_8.png)

# Task-5
![img_9.png](.github/img_9.png)
![img_10.png](.github/img_10.png)